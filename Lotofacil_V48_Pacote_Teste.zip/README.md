# Lotofácil V4.8 — interface inicial

## Iniciar
1. Instale Python 3.10 ou superior.
2. Abra um terminal na pasta deste projeto.
3. Execute `python -m pip install -r requirements.txt`.
4. Execute `python -m streamlit run app.py`.
5. O navegador abrirá a interface local.

## Recursos
- Geração de 5, 10 ou 20 jogos com o motor V4.8 original (não alterado).
- Exportação de snapshot JSON com assinatura SHA-256.
- Importação, conferência de integridade e, para novos snapshots, reprodução matemática.
- Consulta direta ao endpoint oficial da Caixa quando houver conectividade.
- Aferição de carteiras aninhadas de 5, 10 e 20 jogos com prêmios informados pela Caixa.
- Histórico local de snapshots salvos em `dados/`.

## Limitações
- Esta é uma interface Streamlit local, não um aplicativo instalado no celular nem serviço em nuvem.
- A conexão com a Caixa depende de acesso à internet e da disponibilidade do serviço oficial.
- O snapshot P6 legado não inclui `previous_draw`; a assinatura é verificada, mas a reprodução matemática não é refeita nesta interface para esse arquivo.
- O custo da aposta é editável; não há garantia de que o preço padrão esteja atualizado.
- Nenhuma metodologia aumenta comprovadamente a probabilidade de sorteio de uma combinação específica.


## Versão 1.1
Interface responsiva, alerta de orçamento e resposta oficial vinculada ao hash do snapshot. A conexão real com a Caixa ainda precisa ser validada. Streamlit exige execução em computador/servidor.
