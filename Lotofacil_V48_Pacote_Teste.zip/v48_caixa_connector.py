"""CAIXA Lotofacil official API adapter for V4.8.
Never marks a draw official without a successful response from the CAIXA endpoint.
Usage: python v48_caixa_connector.py 3801 --snapshot /path/to/frozen.json
"""
import argparse, json, urllib.request, urllib.error
from datetime import datetime, timezone
from pathlib import Path
from v48_app_core import audit_draw

API='https://servicebus2.caixa.gov.br/portaldeloterias/api/lotofacil/'
PREVIOUS_P6=[1,2,3,4,5,7,8,9,10,12,13,14,15,19,21]

class OfficialResultUnavailable(RuntimeError): pass

def parse_caixa(data, contest):
    if not isinstance(data,dict) or data.get('numero') != contest:
        raise ValueError('CAIXA contest number mismatch or missing')
    raw=data.get('listaDezenas')
    if not isinstance(raw,list) or len(raw)!=15:
        raise ValueError('Invalid official list of numbers')
    numbers=[int(x) for x in raw]
    if len(set(numbers))!=15 or any(x<1 or x>25 for x in numbers):
        raise ValueError('Invalid official draw numbers')
    tiers={}
    for item in data.get('listaRateioPremio',[]):
        try:
            hits=int(item['faixa']); value=float(item['valorPremio'])
            if hits in range(1,6) and value>=0:
                tiers[16-hits]=value  # Caixa faixa 1=15 hits ... faixa 5=11 hits
        except (ValueError,TypeError,KeyError):
            continue
    if not all(n in tiers for n in range(11,16)):
        raise ValueError('Official prize tiers incomplete')
    return numbers,tiers

def fetch_official(contest,timeout=15):
    req=urllib.request.Request(API+str(contest),headers={'Accept':'application/json','User-Agent':'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as res:
            data=json.load(res)
    except (OSError,ValueError,urllib.error.URLError) as exc:
        raise OfficialResultUnavailable(str(exc)) from exc
    return parse_caixa(data,contest)

def evaluate(contest,snapshot):
    numbers,tiers=fetch_official(contest)
    report=audit_draw(str(snapshot),PREVIOUS_P6,numbers,tiers)
    report['source_status']='official_caixa_verified'
    report['source_url']=API+str(contest)
    report['verified_at_utc']=datetime.now(timezone.utc).isoformat()
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('contest',type=int)
    p.add_argument('--snapshot',default='/mnt/data/V48_P6_3801_5vs10_FROZEN.json')
    p.add_argument('--output',default='/mnt/data/V48_CAIXA_OFFICIAL_AUDIT.json')
    a=p.parse_args()
    try:
        report=evaluate(a.contest,Path(a.snapshot))
    except OfficialResultUnavailable as exc:
        print(json.dumps({'status':'NOT_VERIFIED','contest':a.contest,'reason':str(exc),'audit_generated':False},ensure_ascii=False))
        raise SystemExit(2)
    Path(a.output).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':'OFFICIAL_VERIFIED','output':a.output,'groups':report['groups']},ensure_ascii=False))
