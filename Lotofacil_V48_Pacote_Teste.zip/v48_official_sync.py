"""Reliable CAIXA synchronizer. Official records only; never treats cache as live proof."""
from __future__ import annotations
import argparse, hashlib, json, os, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import URLError, HTTPError
from v48_caixa_connector import API, fetch_official, OfficialResultUnavailable
from v48_app_core import audit_draw

PREVIOUS_P6=[1,2,3,4,5,7,8,9,10,12,13,14,15,19,21]


def atomic_json(path, data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.tmp')
    temp.write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True),encoding='utf-8')
    os.replace(temp,path)


def synchronize(contest:int,snapshot:str,cache_dir:str,retries:int=3,delay:float=1.0,fetcher=None):
    """Fetch, validate, audit and persist a record only after live successful CAIXA response.
    Existing cached records remain untouched on failure. Never promote cached data as newly verified.
    """
    if retries<1 or delay<0:raise ValueError('Invalid retry policy')
    obj=json.loads(Path(snapshot).read_text(encoding='utf-8'))
    if obj.get('target_contest')!=contest:raise ValueError('Snapshot contest mismatch')
    fetcher=fetcher or fetch_official
    error=None
    for attempt in range(1,retries+1):
        try:
            numbers,tiers=fetcher(contest)
            if len(numbers)!=15 or len(set(numbers))!=15 or any(not 1<=x<=25 for x in numbers):
                raise ValueError('Invalid CAIXA numbers')
            if not all(x in tiers and tiers[x]>=0 for x in range(11,16)):
                raise ValueError('Missing CAIXA prize tiers')
            report=audit_draw(snapshot,PREVIOUS_P6,numbers,tiers)
            checked=datetime.now(timezone.utc).isoformat()
            source={'contest':contest,'numbers':sorted(numbers),'prizes':{str(k):v for k,v in tiers.items()},
                    'source_url':API+str(contest),'verified_at_utc':checked,'status':'official_live_verified'}
            source['sha256']=hashlib.sha256(json.dumps(source,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
            report.update({'source_status':'official_live_verified','source_url':source['source_url'],'verified_at_utc':checked,'source_sha256':source['sha256']})
            base=Path(cache_dir)
            atomic_json(base/f'caixa_{contest}_official.json',source)
            atomic_json(base/f'v48_{contest}_audit.json',report)
            return {'status':'VERIFIED','attempts':attempt,'record':str(base/f'caixa_{contest}_official.json'),
                    'audit':str(base/f'v48_{contest}_audit.json'),'groups':report['groups']}
        except (OfficialResultUnavailable,URLError,HTTPError,OSError,ValueError) as exc:
            error=str(exc)
            # Fail closed for invalid official payload; retries only for connectivity.
            if isinstance(exc,ValueError):break
            if attempt<retries:time.sleep(delay)
    return {'status':'NOT_VERIFIED','attempts':attempt,'reason':error,'cache_unchanged':True,'audit_generated':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('contest',type=int)
    p.add_argument('--snapshot',default='/mnt/data/V48_P6_3801_5vs10_FROZEN.json')
    p.add_argument('--cache-dir',default='/mnt/data/v48_official_cache')
    p.add_argument('--retries',type=int,default=3);p.add_argument('--delay',type=float,default=1.0)
    a=p.parse_args()
    result=synchronize(a.contest,a.snapshot,a.cache_dir,a.retries,a.delay)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['status']=='VERIFIED' else 2)
