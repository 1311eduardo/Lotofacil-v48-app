"""V4.8 application integration layer. No changes to frozen mathematical engine."""
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
from typing import Iterable
ENGINE_DIR = Path(__file__).parent / 'files'
sys.path.insert(0, str(ENGINE_DIR))
import v48_reproducible_g3d20 as engine

def verify_frozen(snapshot_path: str, previous_draw: Iterable[int]) -> dict:
    obj=json.loads(Path(snapshot_path).read_text(encoding='utf-8'))
    if obj.get('config_sha256') != engine.CONFIG_SHA256:
        raise ValueError('Configuration fingerprint mismatch')
    digest=hashlib.sha256(engine.canonical({k:v for k,v in obj.items() if k!='snapshot_sha256'}).encode()).hexdigest()
    if digest != obj.get('snapshot_sha256'):
        raise ValueError('Snapshot tampering detected')
    target=obj['target_contest']
    if obj['history_through'] != target-1:
        raise ValueError('History cutoff is not prior contest')
    generated=engine.snapshot(target,previous_draw,target-1)
    if generated['snapshot_sha256'] != obj['parent_snapshot_sha256']:
        raise ValueError('Parent snapshot does not reproduce')
    games=obj['portfolio']
    if games != generated['portfolio'][:len(games)]:
        raise ValueError('Portfolio does not reproduce')
    if len(set(map(tuple,games)))!=len(games) or not all(len(g)==15 and len(set(g))==15 and all(1<=n<=25 for n in g) for g in games):
        raise ValueError('Invalid or repeated game')
    return {'verified':True,'contest':target,'games':len(games),'parent_sha256':generated['snapshot_sha256']}

def audit_draw(snapshot_path: str, previous_draw: Iterable[int], result: Iterable[int], prize_table:dict[int,float], unit_cost:float=3.5) -> dict:
    verified=verify_frozen(snapshot_path,previous_draw)
    drawn=set(result)
    if len(drawn)!=15 or any(not 1<=n<=25 for n in drawn):
        raise ValueError('Invalid draw')
    obj=json.loads(Path(snapshot_path).read_text(encoding='utf-8'))
    rows=[{'game':i+1,'hits':len(set(g)&drawn),'prize':prize_table.get(len(set(g)&drawn),0.0)} for i,g in enumerate(obj['portfolio'])]
    groups={}
    for n in (5,10):
        if len(rows)<n:continue
        sub=rows[:n]; stake=round(n*unit_cost,2); returns=round(sum(r['prize'] for r in sub),2)
        groups[str(n)]={'games':n,'winning_games':sum(r['prize']>0 for r in sub),'stake':stake,'return':returns,'net':round(returns-stake,2)}
    return {'verified':verified,'draw':sorted(drawn),'games':rows,'groups':groups,'source_status':'provided_draw_not_live_verified'}

if __name__=='__main__':
    prev=[1,2,3,4,5,7,8,9,10,12,13,14,15,19,21]
    p=str(ENGINE_DIR/'V48_P6_3801_5vs10_FROZEN.json')
    print(json.dumps(verify_frozen(p,prev),ensure_ascii=False,indent=2))
    result=[3,4,7,8,9,11,12,13,15,17,19,20,21,23,24]
    report=audit_draw(p,prev,result,{11:7,12:14,13:35,14:905.56,15:322726.10})
    assert [r['hits'] for r in report['games']]==[7,9,8,11,9,10,9,9,9,8]
    assert report['groups']['5']['net']==-10.5
    assert report['groups']['10']['net']==-28
    Path('/mnt/data/V48_INTEGRATION_TEST_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('INTEGRATION_TEST_PASS')
